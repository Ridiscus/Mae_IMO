import 'dart:convert';
// import 'dart:ui';

import 'package:flutter/material.dart';

import '../../constants/app_colors.dart';

part 'account_model.dart';
part 'user_model.dart';
part 'tenant_model.dart';
part 'estate_type_model.dart';
part 'estate_model.dart';
part 'collection_agent_model.dart';
part 'commercial_model.dart';
part 'agency_model.dart';
part 'tenant_dashboard_model.dart';
part 'document_model.dart';
part 'amenity_model.dart';
part 'payment_history_model.dart';
part 'payment_status_model.dart';
part 'agent_dashboard_model.dart';
part 'tenant_item_model.dart';
part 'tenant_detail_model.dart';
part 'inventory_detail_model.dart';
part 'init_payment_model.dart';
part 'estate_location_model.dart';
part 'chambre_model.dart';
part 'parties_communes_model.dart';
part 'estate_location_response_model.dart';
part 'comptable_info_model.dart';
part 'responses/inventory_model_response.dart';
part 'qr_code_model.dart';
part 'owner_model.dart';
part 'property_model.dart';
part 'activity_model.dart';
part 'commercial_dashboard_model.dart';
